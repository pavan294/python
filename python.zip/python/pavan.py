import packages.math.module3 as p
import math,pconst.const as x
print(p.substract(3,4))
print(math.pi)
x.a=1
print(x.a)