def division(a,b):
    try:
      assert b!=0,"pavan"
      print(a/b)
    except Exception as e:
      print(e)
    else:
      print("success")
    finally:
      print(1)
division(1,2)