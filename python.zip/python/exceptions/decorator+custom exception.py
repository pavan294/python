import math
class custom(Exception):
      def __init__(self,value):
          self.value=value
      def __str__(self):
          return self.value
def smart_div(func):
    def inner(a,b):
        if a<b:
           a,b=b,a
        return func(a,b)
    return inner
@smart_div
def divide(a,b):
    try:
        if a==1:
           raise custom('error')
        else:
            return round(a/b)
    except Exception as e:
        return e
print(divide(1,0))     

