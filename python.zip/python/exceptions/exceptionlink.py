def division():
    try:
      a={'1':2}
      print(a[1])
    except ZeroDivisionError as e:
           print(e)
    
    
division()