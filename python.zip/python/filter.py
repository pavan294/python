import functools
def even(a):
    if a%2==0:
       return True
    return False
def pavan(a,b):
    return a if a>b else b
a=list(filter(even,[1,2,3,4]))
print(a)
b=list(filter(lambda x:x%2==0,[1,2,3,4,5,6]))
b=list(map(lambda x:x%2==0,[1,2,3,4,5,6]))
print(b)
c=functools.reduce(pavan,[2,1,6,4,5])
print(c)

def print_msg(msg):
    # This is the outer enclosing function
    a=1
    def printer():
        # This is the nested function
        print(a+msg)

    return printer  # returns the nested function


# Now let's try calling this function.
# Output: Hello
another = print_msg(1)
another()