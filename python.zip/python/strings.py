p="a,s,b"
l=p.split(',')
print(l)
print(''.join(l))