def outer_function():
    global a 
    a= 20
    def inner_function():
        global a
        a= 30
        return a
    print('a =', a)
    return inner_function
a=10    
k=outer_function()
print(k())
print('a',a)
def outer_function():
    a= 20
    def inner_function():
        nonlocal a
        a= 30   
        print(a)
    inner_function()
    print('a =', a)
k=outer_function()