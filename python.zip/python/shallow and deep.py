import copy
old_list = [[1, 1, 1], [2, 2, 2], [3, 3, 4]]
new_list = copy.deepcopy(old_list)
new_list[1][2]=4
print("Old list:", old_list)
print("New list:", new_list)