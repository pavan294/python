def num(n):
    print(n)
    yield n
    n+=1
    print(n)
    yield n
    n+=1
    print(n)
    yield n
for i in num(1):
    print(i)
a=num(1)
next(a)
next(a)
next(a)
next(a)

    