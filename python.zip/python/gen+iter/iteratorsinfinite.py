class pavan:
        def __iter__(self):
            self.n=0
            return self
        def __next__(self):
            self.n+=1
            return self.n
            
z=pavan()
p=iter(z)
for i in p:
    print(i)
