def product(a, b): 
    print(a*b) 
def product(a, b, c): 
    print(a *b*c) 
product(4, 5, 5)

