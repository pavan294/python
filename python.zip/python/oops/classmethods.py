class Mathematics:
    name="GGK"
    age=10
    def __init__(self,x,y):
        self.x=x
        self.y=y
    #static method
    def addNumbers(x, y):
        return x + y
    @staticmethod
    def pavan():
         return "HELLO"
    #class method
    def printAge(cls):
        print('The age is:', cls.age)

    @classmethod
    def foo(cls):
         return cls.name
    #instance method
    def operate(self): 
        return self.x+self.y
      
# create addNumbers static method
Mathematics.addNumbers = staticmethod(Mathematics.addNumbers)

print('The sum is:', Mathematics.addNumbers(5, 10))
Mathematics.printAge = classmethod(Mathematics.printAge)
Mathematics.printAge()
print(Mathematics.foo())
print(Mathematics.pavan())
a=Mathematics(1,2)
print(a.operate())
