class Parent():
    def __init__(self,value):
        self.value=value
    def show(self,name):
        self.name=name
        print("inside parent")
        return self.name
    def hello(self):
        return self.value+1
class Child(Parent):
    def __init__(self, x):
        super().__init__(x)
    def show(self,name):
        print("inside child")
        super().show(name)
        return self.value
a=Parent(1)
b=Child(2)
print(a.show(1))
print(b.show(2))
print(b.hello())
    