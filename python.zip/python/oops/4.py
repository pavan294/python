class Person:
      age=10
      def show(self,age):
          self.age=age
      @classmethod
      def age(cls,age):
          cls.age=age
      def get(self):
          return self.age
      @staticmethod
      def foo(age):
          return age>18
print(Person.age(20))
p=Person()
print(p.get())