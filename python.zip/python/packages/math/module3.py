def substract(a,b):
    return(a-b)