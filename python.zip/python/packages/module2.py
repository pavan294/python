import module1 as p
print(p.add(1,2))