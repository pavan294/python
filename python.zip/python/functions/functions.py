def hello(b,a=1):
    print(a+b)
hello(2)
def factorial(x):#recursion
   if x == 1 or x==0:
        return 1
   else:
       return (x * factorial(x-1))
print(factorial(3))
def add(*x):
    print(sum(x))
add(1,2,5)
x=lambda x,y:x*y
print(x(4,5))
def outer_func():
    def inner_func():
        return 1
    return inner_func
a=outer_func()
print(a())
def myFun(**wargs):
    print(wargs['first'])
myFun(first ='Geeks', mid ='for', last='Geeks')   
