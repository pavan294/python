a={x for x in range(1,10)}
lb={x for x in range(1,11) if x%2==0}
lc={"even" if x%2==0 else "odd" for x in range(1,11)}
l={x:x for x in range(1,10)}
#print(l)
b={k:v*2 for k,v in l.items()}
c={k:v*2 for k,v in l.items() if v%2==0}
d={k:("even" if v%2==0 else "odd") for k,v in l.items()}
#generator comprehensions
gena = (item for item in a if item > 3 if item>4)
genb= (str(item)+"lesser" if item<3 else str(item)+"greater" for item in a)
print(list(gena))