s=list(map(int,input().split(' ')))
p=max(s)
result=[0]*(p+1)
for i in s:
    result[i]+=1
for i in range(0,len(result)):
    if result[i]==1:
        print(i,end=" ")
'''
INPUT:
1 1 2 2 3 4 5 6
output:
3 4 5 6
'''
