Python 3.9.2 (tags/v3.9.2:1a79785, Feb 19 2021, 13:44:55) [MSC v.1928 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> def fib():
    a, b = 0, 1
    while 1:
        yield a
        a, b = b, a + b

        
>>> z=fib()
>>> next(z)
0
>>> next(z)
1
>>> next(z)
1
>>> next(z)
2
>>> next(z)
3
>>> next(z)
5
>>> next(z)
8
>>> next(z)
13
>>> 