a=set(input().split(' '))
b=set(input().split(' '))
print(list(a.intersection(b)))
print(list(a.union(b)))

'''
INPUT:
1 5 6 8 7 3
8 6 7 9 2
OUTPUT:
['8', '6', '7']
['8', '6', '2', '1', '3', '5', '7', '9']
'''
