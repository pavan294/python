a=input()
l=sorted(a)
s1=''.join(l)
s2=''
for i in s1:
    s2=i+s2
print(int(s2)-int(s1))
'''
INPUT:
126345
OUTPUT:
530865
'''
