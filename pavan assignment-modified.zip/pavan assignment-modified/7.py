s=input()
l=[]
def res(s,i):
    if s.startswith(i) and s.endswith(i):#no of cuts
        return 0
    elif s.startswith(i):
        return 1
    elif s.endswith(i):
        return 1
    else:
        return 2
for i in range(0,len(s)):#generate all substrings and check palindrome
    for j in range(i+2,len(s)+1):
        t=s[i:j]
        if t==t[::-1]:
            l.append(t)
for i in l:
    print(i+"-"+str(res(s,i))+"cuts")

'''
input: poirioky
output:
oirio-2cuts
iri-2cuts'''
