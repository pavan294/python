class Stack:
    def __init__(self):
        self.myList = []
        self.top = -1
        self.max_size=100
    def push(self, item):
       if(len(self.myList)<self.max_size):
            self.myList+=[item]
            self.top+=1
       else:
            print("Stack overflow")
    def pop(self):
        if self.top<=-1:
            return "stack underflow"
        else:
            self.ret= self.myList[self.top]
            self.top = self.top - 1
            return self.ret

    def get_top(self):
        if self.top<=-1:
            return "stack underflow"
        else:
            return self.myList[self.top]
    def get_min(self):
        if self.top<=-1:
            return "stack underflow"
        else:
            z=self.top
            min=self.myList[z]
            while z>=0:
                  if min>self.myList[z]:
                    min=self.myList[z]
                  z-=1
            return min


s=Stack()
s.push(1)
s.push(2)
s.push(3)
print(s.get_min(),"min")
print(s.get_top(),"top")
s.push(4)
print(s.pop(),"pop")
print(s.get_top(),"top")
'''
1 min
3 top
4 pop
3 top'''
