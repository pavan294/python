s=input()
l=[]
match=True
for i in s:
    if i=="(":
        l.append(i)
    elif i==")":
        if len(l)==0:
            match=False
            break
        else:
            l.pop()
    else:
        match=False
        break
if len(l)==0 and match:
    print("True")
else:
    print("False")
'''
INPUT:
(()())
OUTPUT:
True

'''
