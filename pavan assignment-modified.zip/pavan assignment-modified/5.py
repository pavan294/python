s=input()[1:-1].split(',')
from itertools import permutations
l=[int(''.join(i)) for i in permutations(s,len(s))]
print(max(l))
'''
INPUT
[3,8,5,9,98]
OUTPUT
998853
'''
